# keepnote
Quick and Dirty Penetration Testing Notes

These notes are an aggregate over a few years in infosec.  Multiple blogs, videos, my own realizations etc. from everywhere - so many to list.  If you see something and want to be credited, let me know.

It would be nice if the community could make changes and add on to it over time.  Including things like ICS, Blue Teaming, Physical Security, and anything else Infosec related.

The following people I'd like to give credit to as I've used their tools, blogs, and other content to make this KeepNote.  There are more and will update this.

@MrUn1k0d3r \
@harmj0y \
@XssPayloads \
@matterpreter \
@_dirkjan \
@Jacob_Wilkin \
@424f424f \
@byt3bl33d3r \
@vysecurity \
@g0tmi1k \
@nikhil_mitt \
@mainframed767


